# Brasil Político — projeto modular para celular

Este ZIP reaproveita o HTML-base `Brasil_Politico_Calendario_v2.html` e organiza sua interface, estilos e código JavaScript em arquivos separados. O projeto foi preparado para navegador Android e tem configuração inicial para empacotamento com Capacitor.

## Como testar no Android

1. Extraia o ZIP usando um gerenciador de arquivos.
2. Abra a pasta `www`. O arquivo principal é `www/index.html`.
3. Se abrir diretamente pelo gerenciador de arquivos não mantiver o salvamento no seu navegador, use um servidor local offline. No Termux, entre na pasta `www` e execute `python -m http.server 8080`; depois abra `http://127.0.0.1:8080` no navegador.
4. O jogo não precisa de conexão à internet para executar a simulação depois que os arquivos estão no aparelho. A instalação de dependências e a compilação de APK, porém, exigem ferramentas de desenvolvimento e normalmente conexão para baixar pacotes.

## Organização

- `www/index.html`: telas, navegação inferior e estrutura visual.
- `www/css/style.css`: identidade visual responsiva para celular.
- `www/js/core.js`: estado global, utilitários e dados básicos.
- `www/js/modules/storage.js`: salvamento local, exportação/importação JSON, migração e cópia de segurança.
- `www/js/modules/calendar.js`: calendário, ciclos eleitorais e avanço semanal.
- `www/js/modules/education.js`: matrículas, progresso de formação, provas e conclusão. A graduação foi ajustada para quatro períodos de seis meses (24 meses simulados).
- `www/js/modules/life.js`: rede de contatos.
- `www/js/modules/finance.js`: saldo pessoal, investimentos, compras, crédito e dívidas pessoais.
- `www/js/modules/career.js`: emprego, renda extra, promoção e desligamento.
- `www/js/modules/politics.js`: regras eleitorais, candidatura, campanha, debates e visualização dos orçamentos partidário, eleitoral e de gestão.
- `www/js/modules/business.js`: empresa, conta empresarial separada, estoque, vendas, despesas, equipe, gerente, contador, expansão e obrigações persistentes.
- `www/js/modules/actions.js`: coordenação das ações e eventos de jogo já presentes no HTML-base.
- `www/js/modules/ui.js`: renderização, navegação, notícias e preferências visuais.
- `www/js/bootstrap.js`: carregamento do salvamento e registro opcional do service worker.
- `www/manifest.webmanifest` e `www/sw.js`: suporte PWA quando executado em origem HTTP/HTTPS compatível.
- `capacitor.config.json` e `package.json`: ponto de partida para gerar um aplicativo Android.

## Mecânicas disponíveis nesta versão

1. **Iniciar novo jogo:** personagem de 18 anos, nome, estado, município digitado, origem familiar e aparência. Saldo pessoal inicial de R$ 1.500.
2. **Vida pessoal:** atributos de bem-estar, relações, família, filhos, contatos, reputação, confiança, popularidade e credibilidade.
3. **Educação:** cursos livres, profissionalizantes, técnicos, graduação, especialização, mestrado, doutorado e liderança; evolução por calendário e avaliações. Cursos e exigências são simulados.
4. **Trabalho:** busca de emprego, salário, desempenho, experiência, renda extra, promoções e saída do emprego.
5. **Finanças pessoais:** extrato, investimentos simplificados, compras, orçamento, crédito e pagamento de dívidas.
6. **Empresa:** abertura de pequena empresa por capital próprio, empréstimo ou modelo misto; setores; conta separada; preço e demanda; estoque; equipe; gerente; contador; tributos provisionados; expansão para outro município; modo automático; venda ou encerramento. Dívidas e tributos pendentes não são apagados ao fechar/vender e ficam no histórico empresarial.
7. **Política:** filiação partidária, pré-candidatura, registro, campanha, arrecadação simulada, debates, propostas, eleições e resultado. As regras eleitorais são simplificadas e não substituem a legislação vigente.
8. **Governo:** gestão simulada de serviços, economia, transparência, orçamento, negociação, propostas e crises, após conquistar mandato.
9. **Celular interno:** notícias, notificações, eventos aleatórios e decisões com alternativas que alteram atributos ou recursos.
10. **Calendário:** avanço manual por semanas no protótipo-base, com processamento de eventos intermediários. O jogador pode avançar um dia, uma semana, um mês ou um período de seis meses. Os avanços maiores processam cada dia intermediário e pausam se surgir uma decisão pendente.
11. **Salvamento:** localStorage, salvamento após ações relevantes, exportação/importação JSON e cópia de segurança ao iniciar novo jogo.
12. **Acessibilidade visual:** tema claro/escuro, ajuste de tamanho de texto e interface adaptada a telas estreitas.

## Verificação

Execute `npm run check` para verificar a presença dos arquivos, referências locais e sintaxe dos scripts. Execute `npm test` para um smoke test de inicialização, saldo, abertura de empresa, conta empresarial separada, avanço semanal e salvamento local. Esses testes não equivalem a teste completo de equilíbrio, teste em todos os navegadores ou validação jurídica/econômica.

## Gerar APK (ambiente de desenvolvimento)

Com Node.js instalado, execute `npm install`, depois `npx cap add android` (uma única vez), `npx cap sync android` e `npx cap open android`. A compilação final exige Android Studio/SDK ou uma configuração Android compatível. **Este ZIP não contém APK compilado**; contém o projeto-fonte e a configuração para empacotamento.

## Limitações conhecidas e transparência

- A cidade é digitada pelo jogador; não há neste pacote uma base local completa dos 5.570 municípios do IBGE nem população municipal carregada.
- A lista de partidos e os resultados políticos são elementos de simulação, não dados eleitorais oficiais em tempo real.
- A economia empresarial, impostos, salários e campanhas usam valores de jogo simplificados; não constituem orientação contábil, jurídica ou financeira.
- O HTML-base foi preservado como origem do jogo. Algumas ações antigas ainda são coordenadas por `actions.js`; a separação por módulos é funcional, mas o projeto ainda pode receber uma refatoração mais profunda e testes automatizados de comportamento.
