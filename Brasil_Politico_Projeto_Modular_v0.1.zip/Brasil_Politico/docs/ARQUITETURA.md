# Arquitetura do projeto

O app é um projeto web mobile-first com JavaScript clássico e arquivos locais, sem dependência de serviços online durante a simulação. A interface usa `index.html` e `style.css`; o núcleo mantém o estado `G` e os módulos expõem funções globais de domínio para preservar compatibilidade com os handlers existentes no HTML-base.

## Estado global
O estado `G` reúne personagem, finanças pessoais, empresa, histórico empresarial, tesourarias partidárias, contatos, governo, eleição, calendário, notícias, decisões pendentes e histórico. Cada módulo deve alterar apenas seu domínio; ações que cruzam domínios passam pelo despachante ou por funções explícitas.

## Persistência
`storage.js` usa a chave local `brasilPoliticoSave_v1`, faz migração de campos novos e permite exportar/importar JSON. A cópia de segurança de novo jogo usa a chave `brasilPoliticoSave_v1_backup`. Não armazene credenciais ou dados reais sensíveis no salvamento.

## Módulos e ordem de carregamento
`core.js` → storage → calendário → educação → vida → finanças → carreira → política → UI → empresa → ações → bootstrap. Os scripts são locais e carregados em ordem explícita.

## Contratos de integração
- Finanças pessoais e conta empresarial são separadas.
- O calendário é controlado pelo módulo central de calendário.
- Eventos e transações devem ter efeitos idempotentes sempre que houver risco de repetição.
- O salvamento ocorre após ações importantes e ao avançar o tempo.
- Alterações no esquema devem atualizar `migrateSave()` e o teste estrutural.
