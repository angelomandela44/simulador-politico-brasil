# Decisões preservadas do Brasil Político

- Produto: simulador Brasil Político, com inspiração em simuladores de vida e carreira, com foco no Brasil.
- Entrega de desenvolvimento: projeto completo organizado em ZIP com arquivos separados, preparado para uso em celular Android; o APK deverá ser compilado em ambiente Android próprio.
- Arquitetura: híbrida, com módulos independentes e núcleo central.
- Execução: jogo individual e offline; não depende de servidor remoto para simular a partida.
- Tempo: controle manual. O jogador pode avançar manualmente um dia, uma semana, um mês ou um período de seis meses; os dias intermediários são processados e decisões pendentes podem pausar o avanço.
- Salvamento: local, automático após ações importantes e manual, com exportação/importação JSON.
- Início: botão “Iniciar novo jogo”, não “Criar nova partida”; personagem começa aos 18 anos, com nome, município, estado, origem familiar e aparência definidos/gerados.
- Estado inicial financeiro: R$ 1.500 de saldo pessoal.
- Módulos: perfil/vida pessoal, finanças, família, educação, trabalho, empresa, política, governo, calendário, notícias/celular e histórico.
- Empresa: conta empresarial separada da pessoal; opções de capital próprio, empréstimo ou misto; operação, estoque, vendas, equipe, gerente, contador, tributos, expansão e obrigações que permanecem após venda/encerramento.
- Política: contas partidária, eleitoral e de gestão pública separadas na simulação.
- Formação: graduação simplificada para quatro períodos de seis meses (24 meses simulados); demais durações seguem as regras existentes do protótipo.
- Segurança do progresso: iniciar novo jogo não deve sobrescrever silenciosamente o progresso anterior; cria uma cópia de segurança restaurável.
- Integridade: não afirmar que o APK foi compilado nem que todos os sistemas planejados estão completos sem geração e verificação correspondentes.
