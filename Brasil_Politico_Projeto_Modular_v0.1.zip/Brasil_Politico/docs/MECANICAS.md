# Mecânicas — visão do jogador

## Tela inicial e perfil
A primeira tela pede nome, estado, município, origem familiar e aparência. Ao confirmar, o jogo começa aos 18 anos com R$ 1.500 de saldo pessoal e atributos iniciais equilibrados. Ao iniciar outro jogo com progresso existente, o jogo pergunta se deseja continuar; o estado atual é guardado em cópia de segurança antes de reiniciar.

## Navegação mobile
A barra inferior contém Início, Vida, Carreira, Finanças, Sociedade, Empresa, Política, Governo, Celular e Mais. A tela Início resume data, saldo, idade, reputação e bem-estar. A aba Celular concentra notícias e decisões pendentes.

## Tempo e consequências
O jogador escolhe avançar um dia, uma semana, um mês ou um período de seis meses. O processamento paga uma fração do salário mensal, cobra despesas familiares simuladas, atualiza contatos, pode gerar eventos e processa datas de cursos e eleições. O jogo salva após operações importantes. Avançar vários períodos de uma vez não deve ser entendido como implementado nesta versão.

## Educação
Escolha o tipo de formação. Matrícula custa dinheiro e cursos avançam com o calendário. Avaliações têm três perguntas; acertar pelo menos duas é aprovação. Graduação foi configurada para 24 meses simulados, equivalentes a quatro períodos de seis meses; técnico permanece em 24 meses. Os cursos não usam instituições reais ou diplomas oficiais.

## Empresa
A empresa tem conta e extrato próprios, separados do saldo pessoal. Para abrir, informe nome, setor, cidade, estado, capital e financiamento. Capital próprio sai do saldo pessoal; empréstimo aumenta a dívida empresarial; modelo misto combina ambos. Vendas dependem de preço, demanda, reputação, equipe, gerente e estoque. O sistema simula custos semanais, reposição automática de estoque, tributos provisionados, expansão, contratação e modo de operação. Vender ou encerrar interrompe a operação, mas não elimina dívidas ou impostos pendentes.

## Política e governo
A tesouraria partidária, a conta eleitoral do personagem e o orçamento de gestão pública são saldos distintos. Apoio partidário pode ser solicitado quando o personagem é filiado; o saldo partidário é reduzido e o valor entra na conta eleitoral, sem se misturar com o dinheiro pessoal.

O personagem pode se filiar a um partido, preparar pré-candidatura, registrar candidatura no período simulado, arrecadar recursos, participar de debates e apresentar propostas. O ciclo eleitoral varia conforme o ano do jogo. Ao conquistar mandato, libera-se a gestão simulada de serviços, economia, orçamento, transparência e crises.

## Salvamento e segurança
O salvamento é local ao navegador/aplicativo. Exportar progresso gera um JSON que pode ser guardado em outro local. Importar progresso substitui o estado atual após validação básica. Iniciar novo jogo guarda uma cópia de segurança local; a opção de restauração permite recuperá-la. Limpar progresso apaga o salvamento e a cópia de segurança.
