# Testes executados e checklist manual

## Teste automatizado incluído
`npm run check` verifica arquivos obrigatórios, caminhos referenciados pelo HTML, sintaxe JavaScript e presença do painel empresarial e da ação de novo jogo.

## Checklist manual recomendado em Android
- [ ] Iniciar novo jogo com nome e município.
- [ ] Confirmar saldo pessoal inicial e navegação em todas as abas.
- [ ] Avançar um dia, uma semana, um mês e um período; conferir datas, eventos intermediários e pausa por decisão pendente.
- [ ] Conferir calendário, salário/despesas, notícias e salvamento após os avanços.
- [ ] Criar curso, avançar o calendário e fazer uma avaliação.
- [ ] Conseguir emprego, receber salário e testar promoção.
- [ ] Abrir empresa usando capital próprio, empréstimo e modo misto em jogos separados.
- [ ] Confirmar que vendas alteram somente a conta empresarial e o aporte inicial afeta a conta pessoal.
- [ ] Comprar estoque, contratar funcionário, gerente e contador; alterar preço; pausar e retomar operação.
- [ ] Encerrar/vender empresa com dívida e verificar que as obrigações continuam visíveis.
- [ ] Exportar JSON, iniciar novo jogo, restaurar cópia e importar arquivo exportado.
- [ ] Reabrir o app e confirmar que o salvamento permanece disponível.
- [ ] Testar tema escuro, tamanho do texto e uso em tela estreita.

A checklist é recomendação para validação humana; não significa que cada cenário já tenha sido executado em dispositivo Android físico.
