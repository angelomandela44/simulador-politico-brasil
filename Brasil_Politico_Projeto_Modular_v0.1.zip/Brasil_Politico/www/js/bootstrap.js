try{let raw=localStorage.getItem(KEY);if(raw){let x=JSON.parse(raw);if(x.player&&x.fin&&x.gov){G=migrateSave(x);go('home');render()}}}catch(e){}

if('serviceWorker' in navigator && /^https?:$/.test(location.protocol)){navigator.serviceWorker.register('./sw.js').catch(()=>{});}
