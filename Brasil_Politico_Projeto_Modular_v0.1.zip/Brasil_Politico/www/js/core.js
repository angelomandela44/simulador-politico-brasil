const $=x=>document.getElementById(x),clamp=n=>Math.max(0,Math.min(100,Math.round(n))),pick=a=>a[Math.floor(Math.random()*a.length)],fmt=n=>'R$ '+Math.round(n).toLocaleString('pt-BR'),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const states='AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split(' '),parties='Avante,Agir,Cidadania,DC,MDB,Mobiliza,Novo,PCB,PCdoB,PDT,PL,PMB,Podemos,PP,PRD,PRTB,PSB,PSD,PSDB,PSOL,PSTU,PT,PV,Rede Sustentabilidade,Republicanos,Solidariedade,União Brasil,UP'.split(',');
$('state').innerHTML=states.map(s=>'<option '+(s==='RJ'?'selected':'')+'>'+s+'</option>').join('');
let G=null;const KEY='brasilPoliticoSave_v1';
