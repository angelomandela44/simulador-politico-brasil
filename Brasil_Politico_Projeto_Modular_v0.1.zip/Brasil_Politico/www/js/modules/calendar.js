/* Brasil Político — módulo calendar; extraído do HTML-base e organizado para manutenção. */
function today(){return new Date((G.date||(`${G.year}-01-01`)+'T12:00:00'))}

function dateLabel(d){return d.toLocaleDateString('pt-BR',{day:'2-digit',month:'long',year:'numeric'})}

function stamp(){return dateLabel(today())}

function iso(d){return d.toISOString().slice(0,10)}

function currentElectionYear(){return G.year}

function electionKind(y){return y%4===0?'municipal':y%4===2?'geral':'sem eleição'}

function firstSundayOct(y){let d=new Date(y,9,1,12);while(d.getDay()!==0)d.setDate(d.getDate()+1);return d}

function electionDate(y){return iso(firstSundayOct(y))}

function eligibleOffices(y){return y%4===0?['Vereador','Prefeito']:y%4===2?['Deputado estadual','Deputado federal','Senador','Governador','Presidente da República']:[]}

function officeMinAge(o){return o==='Vereador'?18:['Prefeito','Deputado estadual','Deputado federal'].includes(o)?21:o==='Senador'?35:o==='Governador'||o==='Presidente da República'?30:18}

function electionPhase(y, date=G.date){let d=new Date(date+'T12:00:00'), year=Number(y), nowYear=d.getFullYear();if(nowYear!==year)return 'Fora do ciclo';if(!eligibleOffices(year).length)return 'Sem eleição neste ano';let day=iso(d), poll=electionDate(year), month=d.getMonth()+1;if(day>=poll)return day===poll?'Dia da eleição':'Apuração e resultado';if(month<1)return 'Pré-campanha';if(month<=7)return 'Pré-campanha e articulação';if(month===8&&d.getDate()<16)return 'Convenções e registro';if(month===8&&d.getDate()>=16)return 'Campanha oficial';if(month===9)return 'Campanha oficial e debates';if(month===10)return 'Reta final';return 'Calendário eleitoral'}

function calendarStatus(){let phase=electionPhase(G.year);return phase+' • '+(G.election&&G.election.office?'Candidatura: '+G.election.office:'sem candidatura registrada')}

function calendarPanel(){let e=G.election||{},course=G.course;let next=[];if(course)next.push(['Escolaridade',course.nextExam?'Próxima avaliação: '+course.nextExam:'Conclusão prevista em '+course.duration+' meses', 'Progresso '+course.progress+'/'+course.duration+' meses']);next.push(['Eleições',electionPhase(G.year),'Votação: '+dateLabel(new Date(electionDate(G.year)+'T12:00:00'))]);if(e.office)next.push(['Sua candidatura',e.office+' • '+e.status,'Cargo escolhido pelo jogador']);return '<div class="calendar-grid">'+next.map(x=>'<div class="item"><b>'+esc(x[0])+'</b><div>'+esc(x[1])+'</div><small class="muted">'+esc(x[2])+'</small></div>').join('')+'</div><p class="muted">O calendário avança em blocos de 7 dias. Eventos com data marcada são processados quando a semana alcança ou atravessa o prazo.</p>'}

function processCalendarEvents(oldDate,newDate){let old=new Date(oldDate+'T12:00:00'),now=new Date(newDate+'T12:00:00'),p=G.player,e=G.election||{};if(G.course){let monthDiff=(now.getFullYear()-old.getFullYear())*12+(now.getMonth()-old.getMonth());if(monthDiff>0){G.course.progress=Math.min(G.course.duration,G.course.progress+monthDiff);if(G.course.progress>0&&G.course.progress%6===0)G.course.nextExam='agora disponível';if(G.course.progress>=G.course.duration){if(G.course.type==='Curso livre'||G.course.type==='Formação em liderança'){completeCourse()}else if(G.course.nextExam!=='agora disponível'){G.course.nextExam='prova final disponível'}}}}
if(e.office&&e.year===now.getFullYear()){let campaignDate=new Date(e.year,7,16,12),poll=firstSundayOct(e.year);if(!e.campaignStarted&&e.registered&&old<campaignDate&&now>=campaignDate){news('Campanha oficial começou','A campanha para '+e.office+' começou. Confira o celular para os próximos passos.','A campanha oficial da sua candidatura a '+e.office+' começou em 16 de agosto. Organize propostas, recursos e presença pública.','Política');}if(e.campaignStarted){let debateDate=new Date(e.year,8,10,12);if(old<debateDate&&now>=debateDate&&!(e.debates||[]).some(d=>d.scheduled==='1')){news('Debate eleitoral marcado','O primeiro debate da campanha está disponível.','O debate tem perguntas sobre saúde, economia e ética. Acesse a aba Política e participe.','Debate');}if(old<poll&&now>=poll){let cost=e.office==='Vereador'?500:e.office==='Prefeito'?1200:2000;let support=clamp(p.rep*.28+p.popularity*.24+p.credibility*.22+p.trust*.14+p.civic*1.5+G.contacts.length+Math.random()*18);let win=Math.random()<Math.min(.85,.08+support/125+p.courses.length*.02);e.status='Resultado apurado';e.result=win?'Eleito(a) para '+e.office:'Não eleito(a) para '+e.office;e.campaignStarted=false;p.campaign=false;if(win){G.gov.office=e.office;G.gov.approval=clamp(42+support/5);G.gov.budget=e.office==='Prefeito'?1000000:e.office==='Governador'?5000000:e.office==='Presidente da República'?50000000:e.office==='Senador'?300000: e.office==='Deputado estadual'?200000:e.office==='Deputado federal'?250000:150000;p.role=e.office;p.rep=clamp(p.rep+7);news('Resultado eleitoral: vitória','Você foi eleito(a) '+e.office+'.','A apuração simulada foi concluída. Você foi eleito(a) '+e.office+'. A gestão agora aparece na área Governo.','Eleição')}else news('Resultado eleitoral: derrota','Você não venceu a disputa para '+e.office+'.','A apuração foi concluída e você não venceu. Sua rede, reputação e experiência permanecem.','Eleição');log('Resultado eleitoral: '+e.result);}}}}

function advanceByDays(days){
 if(!G)return;
 if(G.pending&&G.pending.length){alert('Resolva as decisões pendentes no Celular antes de avançar o tempo.');return}
 days=Math.max(1,Math.min(366,Math.floor(Number(days)||1)));
 G.daysElapsed=Number.isFinite(G.daysElapsed)?G.daysElapsed:0;
 let moved=0;
 for(let i=0;i<days;i++){
  const oldDate=G.date||String(G.year||2026)+'-01-01';
  const oldYear=Number(oldDate.slice(0,4));
  const d=new Date(oldDate+'T12:00:00');d.setDate(d.getDate()+1);G.date=iso(d);G.year=d.getFullYear();G.daysElapsed++;moved++;
  processCalendarEvents(oldDate,G.date);
  if(G.year>oldYear){G.player.age++;news('Aniversário','Você completou '+G.player.age+' anos.','Você completou '+G.player.age+' anos em '+stamp()+'.','Vida pessoal')}
  if(G.daysElapsed%7===0){
   const p=G.player;
   if(p.job){tx('Salário semanal',Math.round(p.job.salary/4));p.job.weeksWorked=(p.job.weeksWorked||0)+1;if(p.job.weeksWorked%4===0){p.job.months=(p.job.months||0)+1;p.job.performance=clamp(p.job.performance+(Math.random()<.58?1:-1));if(p.job.months%12===0&&p.job.performance>65){p.job.salary+=200;news('Reconhecimento profissional','Você recebeu um aumento.')}}}
   const cost=250+(p.children||0)*90+(p.relationship?35:0);
   if(G.fin.balance>=cost)tx('Despesas básicas',-cost);else{const short=cost-G.fin.balance;if(G.fin.balance>0)tx('Despesas básicas',-G.fin.balance);G.fin.balance=0;G.fin.debt+=short;p.mood=clamp(p.mood-5);news('Pressão financeira','O saldo não cobriu as despesas; a dívida aumentou '+fmt(short)+'.')}
   G.fin.invest=Math.round(G.fin.invest*1.0005*100)/100;
   G.contacts.forEach(c=>{if(Math.random()<.15)c.relation=clamp(c.relation+(Math.random()<.5?1:-1))});
   if(Math.random()<.25)randomEvent();
   if(G.gov.office){G.gov.approval=clamp(G.gov.approval+Math.round((G.gov.services+G.gov.economy-100)/55));if(G.gov.budget<0){G.gov.approval=clamp(G.gov.approval-3);news('Alerta fiscal','O orçamento público está negativo e a oposição cobra explicações.')}}
   if(typeof tickBusiness==='function')tickBusiness();
   G.week=(G.week||1)+1;if(G.week>53)G.week=1;
  }
  if(G.pending&&G.pending.length)break;
 }
 G.processed=G.week;save();render();
}
function advance(){advanceByDays(7)}
function advanceDay(){advanceByDays(1)}
function advanceMonth(){advanceByMonths(1)}
function advancePeriod(){advanceByMonths(6)}
function advanceByMonths(months){if(!G)return;const current=new Date((G.date||String(G.year||2026)+'-01-01')+'T12:00:00');const day=current.getDate();const targetMonth=current.getMonth()+Math.max(1,Math.floor(Number(months)||1));const target=new Date(current.getFullYear(),targetMonth,1,12);const last=new Date(target.getFullYear(),target.getMonth()+1,0,12).getDate();target.setDate(Math.min(day,last));const days=Math.max(1,Math.round((target-current)/86400000));advanceByDays(days)}
