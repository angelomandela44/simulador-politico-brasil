/* Sistema de trabalho e progressão profissional. */
function careerAction(a){let p=G.player;
 if(a==='job'){if(p.job){alert('Você já está empregado. Use trabalho extra ou promoção.');return}let j=pick([['Atendente',1900],['Assistente administrativo',2400],['Auxiliar de serviços',1750],['Vendedor',2100],['Estagiário',1300],['Assistente de projetos',2600]]);p.job={title:j[0],salary:j[1],months:0,performance:55};done('Novo emprego','Você conseguiu uma vaga como '+j[0]+', com salário simulado de '+fmt(j[1])+' por mês.')}
 else if(a==='gig'){let n=pick([100,160,220,300,380]);tx('Trabalho extra',n);p.mood=clamp(p.mood-3);done('Renda extra','Você recebeu '+fmt(n)+' por um trabalho temporário.')}
 else if(a==='quit'){if(!p.job){alert('Você não tem emprego.');return}let old=p.job.title;p.job=null;done('Saída do emprego','Você deixou o trabalho de '+old+'.')}
 else if(a==='promotion'){if(!p.job||p.job.months<3){alert('Tenha um emprego e acumule pelo menos três meses de experiência.');return}if(Math.random()<p.job.performance/100){p.job.salary+=250;done('Promoção conquistada','Seu salário mensal aumentou R$ 250.')}else done('Promoção recusada','Melhore o desempenho e tente novamente.')}
}
