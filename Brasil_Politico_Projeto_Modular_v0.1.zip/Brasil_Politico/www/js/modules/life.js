/* Brasil Político — módulo life; extraído do HTML-base e organizado para manutenção. */
function contact(role){let c={name:pick(['Marina','Rafael','Camila','André','João','Luana','Beatriz','Pedro','Renata','Thiago','Lívia','Mateus']),role,relation:pick([42,50,58,65,72]),known:'Conhecido em '+G.player.city};G.contacts.unshift(c);G.contacts=G.contacts.slice(0,40);G.player.contactsCount++;return c}
