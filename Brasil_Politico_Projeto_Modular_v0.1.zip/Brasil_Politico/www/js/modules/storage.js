/* Brasil Político — módulo storage; extraído do HTML-base e organizado para manutenção. */
function log(text){G.history.unshift({week:G.week,year:G.year,date:G.date||null,text});G.history=G.history.slice(0,150)}

function news(title,text,detail=null,type='info'){let n={id:Date.now()+Math.floor(Math.random()*10000),week:G.week,year:G.year,date:G.date||null,title,text,detail:detail||text,type,read:false};G.news.unshift(n);G.news=G.news.slice(0,80);if(G.notificationPermission&&'Notification'in window&&Notification.permission==='granted'){try{let no=new Notification(title,{body:text,tag:String(n.id)});no.onclick=()=>{window.focus();openReader(n.id);no.close()}}catch(e){}}}

function save(){if(!G)return;try{localStorage.setItem(KEY,JSON.stringify(G));return true}catch(e){console.error('Falha ao salvar',e);return false}}

function exportSave(){let a=document.createElement('a'),u=URL.createObjectURL(new Blob([JSON.stringify(G,null,2)],{type:'application/json'}));a.href=u;a.download='Brasil_Politico_Progresso.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}

function importSave(){let f=$('file').files[0];if(!f){alert('Escolha um arquivo JSON.');return}let r=new FileReader();r.onload=()=>{try{let x=JSON.parse(r.result);if(!x.player||!x.fin||!x.gov)throw Error();G=migrateSave(x);save();go('home');render();alert('Progresso importado.')}catch(e){alert('Arquivo inválido.')}};r.readAsText(f)}

function reset(){if(confirm('Apagar o progresso salvo e reiniciar a carreira?')){localStorage.removeItem(KEY);localStorage.removeItem(KEY+'_backup');location.reload()}}

function migrateSave(x){if(!('business' in x))x.business=null;if(!Array.isArray(x.businessHistory))x.businessHistory=[];if(!x.partyAccounts||typeof x.partyAccounts!=='object')x.partyAccounts={};if(!x.date)x.date=String(x.year||2026)+'-01-01';if(!Number.isFinite(x.daysElapsed))x.daysElapsed=Math.max(0,((x.week||1)-1)*7);if(!x.course)x.course=null;if(!x.election)x.election={office:null,status:'none',year:null,registered:false,campaignStarted:false,debates:[],result:null};if(!x.news)x.news=[];if(!x.pending)x.pending=[];if(!x.notificationPermission)x.notificationPermission=false;return x}

function restoreBackup(){let raw=null;try{raw=localStorage.getItem(KEY+'_backup')}catch(e){}if(!raw){alert('Não existe cópia de segurança neste aparelho.');return}if(G&&!confirm('Restaurar a cópia de segurança? O estado atual do jogo será substituído.'))return;try{let x=JSON.parse(raw);if(!x.player||!x.fin||!x.gov)throw Error();G=migrateSave(x);save();go('home');render();alert('Cópia de segurança restaurada.')}catch(e){alert('A cópia de segurança está inválida.')}}
function newGamePrompt(){if(G&&!confirm('Iniciar um novo jogo? O progresso atual será guardado como cópia de segurança neste aparelho antes de começar.'))return;if(G){try{localStorage.setItem(KEY+'_backup',JSON.stringify(G))}catch(e){alert('Não foi possível criar a cópia de segurança. Libere espaço no navegador e tente novamente.');return}}G=null;go('setup');$('name').value='';$('name').focus()}
